var reportClearQuestStatusObject = (function () {
    var sprvalidationbtnElement, fourthColumnElement;

    var init = function () {
        cacheElements();;
        loadBuildsData();
        bindEvents();
    };

    var cacheElements = function () {
        sprvalidationbtnElement = $("#sprvalidationbtn");

    };

    var bindEvents = function () {
        sprvalidationbtnElement.on("click", function () {
            fourthColumnElement = $(".status");
            $('.spanstatus').remove();
            checkSPRstatus();
            //$(sprvalidationbtnElement).unbind("click");
        });
    };

    var checkSPRstatus = function () {
        $.each(fourthColumnElement, function (index, value) {
            var randomCollection = Math.floor(Math.random() * 10);
            if (randomCollection > 5) {
                $(this).css("background-color", "green");
            }
            else {
                $(this).css("background-color", "red");
                $(this).attr({
                    'data-toggle': 'tooltip',
                    'data-placement': 'left',
                    'title': 'response is null'

                });
                $(this).tooltip();
            }
        });
    };
    var loadBuildsData = function () {
        var buildVersion = [];
        var buildDetails = [];
        getDataObj.getBuildsData()
            .then(function (response) {
                var options = "";
                $.each(response, function (index, value) {
                    options += "<option>" + value.buildversion + "</option>";
                    buildVersion.push(value.buildversion);
                    buildDetails.push(response[index]);
                });

                $("#builds").append(options);
            });
        $("#builds").on("change", function () {
            $("#data").empty();
            var selectedOption = $("#builds option:selected").text();
            var rows = "";
            if (selectedOption !== "Select") {
                for (var buildNumber = 0; buildNumber < buildVersion.length; buildNumber++) {
                    if (buildVersion[buildNumber] == selectedOption) {
                        var details = buildDetails[buildNumber];
                        $.each(details.data, function (i, v) {
                            rows += "<tr><td>" + v["serial number"] + "</td><td>" + v["SPR"] + "</td><td>" + v["Submitter"] + "</td><td class='status'></td></tr>";
                        });
                        $("#data").append(rows);
                    }
                }
            }
        });
    }

    return {
        init: init
    }
})();
reportClearQuestStatusObject.init();