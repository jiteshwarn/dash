var getDataObj = {
    // getClearQuestdata: function () {
    //     return $.get("https://api.myjson.com/bins/10v3kl");
    // },
    getBuildsData: function () {
        //return $.get("builddata.json");
        return $.get("https://api.myjson.com/bins/yq1q9");
    },    
}
